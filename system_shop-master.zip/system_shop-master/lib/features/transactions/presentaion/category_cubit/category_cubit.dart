import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:system_shop/core/database/api/dio_consumer.dart';
import 'package:system_shop/core/database/api/end_point.dart';
import 'package:system_shop/features/transactions/data/data_source/category_remote_data_source.dart';
import 'package:system_shop/features/transactions/data/model/get_all_sales.dart';
import 'package:system_shop/features/transactions/data/model/product_by_category.dart';
import 'package:system_shop/features/transactions/data/model/product_dtails.dart';
import 'package:system_shop/features/transactions/data/model/product_image.dart';
import 'package:system_shop/features/transactions/presentaion/category_cubit/category_state.dart';
// import 'package:system_shop/features/home/data/model/category_model.dart';

class CategoryCubit extends Cubit<CategoryStates> {
  CategoryCubit() : super(IntitialCategoryState());
  static CategoryCubit get(context) => BlocProvider.of(context);

  GetAllSales? allSales;
  var dioHelper = DioHelper.instance;
  // Category
  // getAllSales() async {
  //   emit(GetCategoryLoading());
  //   var list = await CategoryServices.getAllSales();
  //   if (list?.status == true) {
  //     allSales = list?.data ?? [];
  //     emit(GetCategorySucsses());
  //   } else if (list?.status == false) {
  //     emit(GetCategoryError());
  //   } else {
  //     emit(GetCategoryFailed());
  //   }
  // }

  getAllSales() async {
    await dioHelper
        .get(
      endpoint: ApiUrls.ALL_SALES_URL,
    )
        .then((value) {
      allSales = GetAllSales.fromJson(value!.data);
      emit(GetCategorySucsses());
    }).catchError((er) {
      print(er.toString());
      emit(GetCategoryError());
    });
  }
}
