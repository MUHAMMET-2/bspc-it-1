class GetCredit {
  bool? status;
  String? num;
  String? msg;
  List<CreditData>? data;

  GetCredit({this.status, this.num, this.msg, this.data});

  GetCredit.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    num = json['Num'];
    msg = json['msg'];
    if (json['data'] != null) {
      data = <CreditData>[];
      json['data'].forEach((v) {
        data!.add(new CreditData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['Num'] = this.num;
    data['msg'] = this.msg;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CreditData {
  int? id;
  int? credit;
  String? date;
  int? shopId;
  String? createdAt;
  String? updatedAt;

  CreditData(
      {this.id,
      this.credit,
      this.date,
      this.shopId,
      this.createdAt,
      this.updatedAt});

  CreditData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    credit = json['credit'];
    date = json['date'];
    shopId = json['shop_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['credit'] = this.credit;
    data['date'] = this.date;
    data['shop_id'] = this.shopId;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
