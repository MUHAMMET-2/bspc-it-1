class AppConst {
  static String kLogin = 'Login';
}

String? uid;
