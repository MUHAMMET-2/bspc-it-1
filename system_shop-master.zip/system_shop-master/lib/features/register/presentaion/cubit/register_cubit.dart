import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:system_shop/features/login/data/data_source/remote_data_source.dart';
import 'package:system_shop/features/login/data/models/login_model.dart';
import 'package:system_shop/features/login/presentaion/cubit/login_states.dart';
import 'package:system_shop/features/register/data/data_source/remote_data_source.dart';
import 'package:system_shop/features/register/data/models/register_model.dart';
import 'package:system_shop/features/register/data/models/register_model.dart';
import 'package:system_shop/features/register/presentaion/cubit/register_states.dart';

class RegisterCubit extends Cubit<RegisterStates> {
  RegisterCubit() : super(RegisterInstialState());

  static RegisterCubit get(context) => BlocProvider.of(context);

  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController companyController = TextEditingController();
  TextEditingController shopNameController = TextEditingController();
  RegisterModel? registerModel;
  Future register() async {
    emit(RegisterLoading());
    var user = await RegisterServices.register(
      email: emailController.text,
      password: passwordController.text,
      company: companyController.text,
      shopName: shopNameController.text,
      name: nameController.text,
      phone: phoneController.text,
    );
    if (user?.user != null) {
      registerModel = user;
      emit(RegisterSuccess());
    } else {
      emit(RegisterError());
    }
  }
}
