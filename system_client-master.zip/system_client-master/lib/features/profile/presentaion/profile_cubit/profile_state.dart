abstract class ProfileState {}

class IntitialProfileStates extends ProfileState {}
class LogoutSucsess extends ProfileState {}

class GetPendingClientLoading extends ProfileState {}

class GetPendingClientSucsses extends ProfileState {}

class GetPendingClientError extends ProfileState {}

class GetPendingClientFailed extends ProfileState {}
class GetReturnFundsLoading extends ProfileState {}

class GetReturnFundsSucsses extends ProfileState {}

class GetReturnFundsError extends ProfileState {}

class GetReturnFundsFailed extends ProfileState {}
class GetUserDataLoading extends ProfileState {}

class GetUserDataSucsses extends ProfileState {}

class GetUserDataError extends ProfileState {}

class GetUserDataFailed extends ProfileState {}
class GetCategoryLoading extends ProfileState {}

class GetCategorySucsses extends ProfileState {}

class GetCategoryError extends ProfileState {}

class GetCategoryFailed extends ProfileState {}
class ActiveClientLoading extends ProfileState {}

class ActiveClientSucsses extends ProfileState {}

class ActiveClientError extends ProfileState {}

class ActiveClientFailed extends ProfileState {}
