class HomeServices{

  Future getBanner()async{

  }
}