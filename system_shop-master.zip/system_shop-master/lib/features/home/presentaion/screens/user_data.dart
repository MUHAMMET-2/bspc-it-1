import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:system_shop/core/colors/colors.dart';
import 'package:system_shop/core/componant/componant.dart';
import 'package:system_shop/core/componant/defult_button.dart';
import 'package:system_shop/features/home/presentaion/home_cubit/home_cubit.dart';
import 'package:system_shop/features/home/presentaion/home_cubit/home_state.dart';

class UserData extends StatefulWidget {
  const UserData({super.key});

  @override
  State<UserData> createState() => _UserDataState();
}

class _UserDataState extends State<UserData> {
  String? amount;
  bool isCompany = false;
  int? companyId;
  String? companyName;
  bool isPrice = false;
  @override
  Widget build(BuildContext context) {
    return BlocConsumer<HomePageCubit, HomeState>(
        listener: (context, state) {},
        builder: (context, state) {
          HomePageCubit cubit = HomePageCubit.get(context);
          return Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: SingleChildScrollView(
                child: cubit.scanClientById == null
                    ? Center(
                        child: CircularProgressIndicator(
                        color: AppColors.buttonGreenColor,
                      ))
                    : Stack(
                        // alignment: Alignment.bottomCenter,
                        children: [
                          Container(
                            height: 430.h,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: AppColors.buttonRedColor,
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(
                                  top: 60.h, left: 12, right: 12),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      defaultText(
                                          txt: 'بيانات العميل',
                                          fontSize: 20.sp,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white),
                                      SizedBox(
                                        width: 30.w,
                                      ),
                                      InkWell(
                                        onTap: () {
                                          pop(context);
                                        },
                                        child: Icon(
                                          Icons.arrow_forward,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 50.h,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Flexible(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                defaultText(
                                                    txt: cubit.scanClientById!
                                                            .data!.number ??
                                                        '',
                                                    color: Colors.white,
                                                    fontSize: 11,
                                                    fontWeight:
                                                        FontWeight.bold),
                                                SizedBox(
                                                  width: 10.w,
                                                ),
                                                Icon(
                                                  Icons.phone_in_talk_sharp,
                                                  color: Colors.white,
                                                )
                                              ],
                                            ),
                                            SizedBox(
                                              height: 20.h,
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                defaultText(
                                                    txt: cubit.scanClientById!
                                                            .data!.cityName ??
                                                        '',
                                                    color: Colors.white,
                                                    fontSize: 11,
                                                    fontWeight:
                                                        FontWeight.bold),
                                                SizedBox(
                                                  width: 10.w,
                                                ),
                                                Icon(
                                                  Icons.location_pin,
                                                  color: Colors.white,
                                                )
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizedBox(
                                        width: 20.w,
                                      ),
                                      Flexible(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                defaultText(
                                                    txt: cubit.scanClientById!
                                                            .data!.name ??
                                                        '',
                                                    color: Colors.white,
                                                    fontSize: 13,
                                                    fontWeight:
                                                        FontWeight.bold),
                                                SizedBox(
                                                  width: 10.w,
                                                ),
                                                cubit.scanClientById!.data!
                                                            .image ==
                                                        ''
                                                    ? Image.asset(
                                                        'assets/images/man.png',
                                                        height: 30,
                                                        width: 30,
                                                      )
                                                    : Container(
                                                        height: 30.h,
                                                        width: 30.w,
                                                        decoration: BoxDecoration(
                                                            shape:
                                                                BoxShape.circle,
                                                            image: DecorationImage(
                                                                image: NetworkImage(cubit
                                                                    .scanClientById!
                                                                    .data!
                                                                    .image
                                                                    .toString()))),
                                                      ),
                                              ],
                                            ),
                                            SizedBox(
                                              height: 20.h,
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                defaultText(
                                                    txt: cubit.scanClientById!
                                                            .data!.number ??
                                                        '',
                                                    color: Colors.white,
                                                    fontSize: 11,
                                                    fontWeight:
                                                        FontWeight.bold),
                                                SizedBox(
                                                  width: 10.w,
                                                ),
                                                Icon(
                                                  CupertinoIcons.info_circle,
                                                  color: Colors.white,
                                                )
                                              ],
                                            ),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    height: 20.h,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          setState(() {
                                            isPrice = !isPrice;
                                          });
                                        },
                                        child: Container(
                                          height: 40.h,
                                          width: 190.w,
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(14),
                                              color: AppColors.buttonblueColor),
                                          child: Center(
                                            child: defaultText(
                                                txt: isPrice == false
                                                    ? 'مرتجع'
                                                    : 'ارسال الاموال',
                                                fontSize: 16.sp,
                                                color: Colors.white),
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 10.w,
                                      ),
                                      Icon(
                                        Icons.money_off_csred,
                                        color: Colors.white,
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    height: 100.h,
                                  ),
                                  defaultText(
                                      txt: isPrice == false
                                          ? 'هل تود ارسال اموال الي العميل'
                                          : 'هل تود ارجاع اموال الي العميل',
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 410.h),
                            child: Container(
                              height: 300.h,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(30),
                                    topRight: Radius.circular(30)),
                                color: Colors.white,
                              ),
                              child: Padding(
                                padding: EdgeInsets.only(
                                    top: 30.h, left: 12, right: 12),
                                child: Column(
                                  children: [
                                    InkWell(
                                      onTap: () {
                                        setState(() {
                                          isCompany = true;
                                        });
                                      },
                                      child: Container(
                                        height: 45.h,
                                        padding: EdgeInsets.all(10),
                                        width: double.infinity,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(14),
                                            border: Border.all(width: .3)),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            defaultText(
                                                txt: companyName ??
                                                    'اختر الشركه',
                                                fontSize: 13.sp,
                                                fontWeight: FontWeight.bold),
                                            Icon(Icons.arrow_drop_down)
                                          ],
                                        ),
                                      ),
                                    ),
                                    Stack(
                                      children: [
                                        Column(
                                          children: [
                                            SizedBox(
                                              height: 20.h,
                                            ),
                                            TextFormField(
                                              keyboardType:
                                                  TextInputType.number,
                                              controller: cubit.price,
                                              onChanged: (value) {
                                                setState(() {
                                                  amount = value;
                                                });
                                              },
                                              decoration: InputDecoration(
                                                  contentPadding: EdgeInsets.only(
                                                      top:
                                                          30), // border: InputBorder.none,
                                                  // errorText: emailError,
                                                  enabledBorder:
                                                      OutlineInputBorder(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(16),
                                                          borderSide: BorderSide(
                                                              color: AppColors
                                                                  .greyColor,
                                                              width: 1)),
                                                  focusedBorder: OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              16),
                                                      borderSide: BorderSide(
                                                          color: AppColors
                                                              .buttonRedColor,
                                                          width: 1)),
                                                  hintText:
                                                      'ادخل القيمه التي تود ارسالها للعميل',
                                                  prefixIcon: Icon(
                                                    Icons.edit,
                                                    color: AppColors.greyColor,
                                                  )),
                                            ),
                                            SizedBox(
                                              height: 30.h,
                                            ),
                                            InkWell(
                                              onTap: () {
                                                if (isPrice == true) {
                                                  cubit.addReturnFund(
                                                    clientId: cubit
                                                        .scanClientById!
                                                        .data!
                                                        .id,
                                                    companyId: companyId,
                                                  );
                                                }else{
 cubit.addNewFund(
                                                    clientId: cubit
                                                        .scanClientById!
                                                        .data!
                                                        .id,
                                                    companyId: companyId,
                                                  );
                                                }
                                              },
                                              child: Container(
                                                height: 45.h,
                                                width: double.infinity,
                                                decoration: BoxDecoration(
                                                  color:
                                                      AppColors.buttonblueColor,
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                ),
                                                child: Center(
                                                  child: defaultText(
                                                      txt: 'اكتمال',
                                                      color: Colors.white,
                                                      fontSize: 16,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                        if (isCompany == true)
                                          BlocProvider(
                                            create: (context) => HomePageCubit()
                                              ..getCompanyList(),
                                            child:
                                                BlocConsumer<HomePageCubit,
                                                        HomeState>(
                                                    listener:
                                                        (context, state) {},
                                                    builder: (context, state) {
                                                      HomePageCubit homecubit =
                                                          HomePageCubit.get(
                                                              context);
                                                      return homecubit
                                                              .companyList
                                                              .isEmpty
                                                          ? SizedBox()
                                                          : Container(
                                                              height: 200.h,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: Colors
                                                                    .white,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            14),
                                                              ),
                                                              child: ListView
                                                                  .separated(
                                                                      itemBuilder:
                                                                          (context, index) =>
                                                                              Padding(
                                                                                padding: const EdgeInsets.all(8.0),
                                                                                child: InkWell(
                                                                                  onTap: () {
                                                                                    setState(() {
                                                                                      companyId = homecubit.companyList[index].id;
                                                                                      companyName = homecubit.companyList[index].name;
                                                                                      isCompany = false;
                                                                                    });
                                                                                  },
                                                                                  child: defaultText(txt: homecubit.companyList[index].name),
                                                                                ),
                                                                              ),
                                                                      separatorBuilder:
                                                                          (context, index) =>
                                                                              SizedBox(
                                                                                height: 15,
                                                                                child: Divider(
                                                                                  color: Colors.grey.shade200,
                                                                                ),
                                                                              ),
                                                                      itemCount: homecubit
                                                                          .companyList
                                                                          .length),
                                                            );
                                                    }),
                                          )
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          );
        });
  }
}
