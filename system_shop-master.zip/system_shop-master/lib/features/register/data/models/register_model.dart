class RegisterModel {
  String? accessToken;
  String? tokenType;
  int? expiresIn;
  User? user;

  RegisterModel({this.accessToken, this.tokenType, this.expiresIn, this.user});

  RegisterModel.fromJson(Map<String, dynamic> json) {
    accessToken = json['access_token'];
    tokenType = json['token_type'];
    expiresIn = json['expires_in'];
    user = json['user'] != null ? new User.fromJson(json['user']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['access_token'] = this.accessToken;
    data['token_type'] = this.tokenType;
    data['expires_in'] = this.expiresIn;
    if (this.user != null) {
      data['user'] = this.user!.toJson();
    }
    return data;
  }
}

class User {
  int? id;
  String? name;
  String? phone;
  String? taxAccount;
  String? registerAccount;
  String? shopName;
  String? brunches;
  String? company;
  String? email;
  Null? emailVerifiedAt;
  String? password;
  int? status;
  Null? rememberToken;
  String? createdAt;
  String? updatedAt;

  User(
      {this.id,
      this.name,
      this.phone,
      this.taxAccount,
      this.registerAccount,
      this.shopName,
      this.brunches,
      this.company,
      this.email,
      this.emailVerifiedAt,
      this.password,
      this.status,
      this.rememberToken,
      this.createdAt,
      this.updatedAt});

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    phone = json['phone'];
    taxAccount = json['tax_account'];
    registerAccount = json['register_account'];
    shopName = json['shop_name'];
    brunches = json['brunches'];
    company = json['company'];
    email = json['email'];
    emailVerifiedAt = json['email_verified_at'];
    password = json['password'];
    status = json['status'];
    rememberToken = json['remember_token'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['phone'] = this.phone;
    data['tax_account'] = this.taxAccount;
    data['register_account'] = this.registerAccount;
    data['shop_name'] = this.shopName;
    data['brunches'] = this.brunches;
    data['company'] = this.company;
    data['email'] = this.email;
    data['email_verified_at'] = this.emailVerifiedAt;
    data['password'] = this.password;
    data['status'] = this.status;
    data['remember_token'] = this.rememberToken;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
