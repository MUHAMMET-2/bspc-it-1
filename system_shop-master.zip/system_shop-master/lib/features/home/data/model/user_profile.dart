class UserProfile {
  int? id;
  String? name;
  String? email;
  String? phone;
  String? address;
  String? location;
  dynamic totalSale;
  dynamic credit;
  int? cityId;
  String? cityName;
  String? logo;
  String? qr;

  UserProfile(
      {this.id,
      this.name,
      this.email,
      this.credit,
      this.phone,
      this.address,
      this.location,
      this.totalSale,
      this.cityId,
      this.cityName,
      this.logo,
      this.qr});

  UserProfile.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    credit = json['credit'];
    phone = json['phone'];
    address = json['address'];
    location = json['location'];
    totalSale = json['total_sale'];
    cityId = json['city_id'];
    cityName = json['city_name'];
    logo = json['logo'];
    qr = json['qr'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['credit'] = this.credit;
    data['phone'] = this.phone;
    data['address'] = this.address;
    data['location'] = this.location;
    data['total_sale'] = this.totalSale;
    data['city_id'] = this.cityId;
    data['city_name'] = this.cityName;
    data['logo'] = this.logo;
    data['qr'] = this.qr;
    return data;
  }
}
