package com.system.kalde_client

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
