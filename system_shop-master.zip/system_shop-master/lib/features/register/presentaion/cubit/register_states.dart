abstract class RegisterStates {}

class RegisterInstialState extends RegisterStates {}
class RegisterLoading extends RegisterStates {}

class RegisterSuccess extends RegisterStates {}

class RegisterError extends RegisterStates {}
