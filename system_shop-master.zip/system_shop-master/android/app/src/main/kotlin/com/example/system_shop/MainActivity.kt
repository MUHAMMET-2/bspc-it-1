package com.system.kalde_shopping

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
