abstract class CategoryStates{}
class IntitialCategoryState extends CategoryStates{}
class GetCategoryLoading extends CategoryStates {}

class GetCategorySucsses extends CategoryStates {}

class GetCategoryError extends CategoryStates {}

class GetCategoryFailed extends CategoryStates {}
class GetProductByCategoryDataLoading extends CategoryStates {}

class GetProductByCategoryDataSucsses extends CategoryStates {}

class GetProductByCategoryDataError extends CategoryStates {}

class GetProductByCategoryDataFailed extends CategoryStates {}
class GetProductDetailsLoading extends CategoryStates {}

class GetProductDetailsSucsses extends CategoryStates {}

class GetProductDetailsError extends CategoryStates {}

class GetProductDetailsFailed extends CategoryStates {}
class GetProductImageLoading extends CategoryStates {}

class GetProductImageSucsses extends CategoryStates {}

class GetProductImageError extends CategoryStates {}

class GetProductImageFailed extends CategoryStates {}