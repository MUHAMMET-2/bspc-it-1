abstract class HomeStates{}
class IntitialHomeState extends HomeStates{}
class ChangeIndexState extends HomeStates{}