class ProductDetailsModel {
  bool? status;
  String? num;
  String? msg;
  ProductDetailsData? data;

  ProductDetailsModel({this.status, this.num, this.msg, this.data});

  ProductDetailsModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    num = json['Num'];
    msg = json['msg'];
    data = json['data'] != null ? new ProductDetailsData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['Num'] = this.num;
    data['msg'] = this.msg;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class ProductDetailsData {
  int? samehId;
  String? samehName;
  String? samehFrontImage;
  String? samehSku;
  int? samehWight;
  int? samehCool;
  int? samehExpire;
  String? samehCover;
  double? samehAdminPriceAfter;
  String? samehNotes;
  int? samehCategoryId;
  int? samehSupplierId;
  int? samehPartnerId;

  ProductDetailsData(
      {this.samehId,
      this.samehName,
      this.samehFrontImage,
      this.samehSku,
      this.samehWight,
      this.samehCool,
      this.samehExpire,
      this.samehCover,
      this.samehAdminPriceAfter,
      this.samehNotes,
      this.samehCategoryId,
      this.samehSupplierId,
      this.samehPartnerId});

  ProductDetailsData.fromJson(Map<String, dynamic> json) {
    samehId = json['sameh_id'];
    samehName = json['sameh_name'];
    samehFrontImage = json['sameh_front_image'];
    samehSku = json['sameh_sku'];
    samehWight = json['sameh_wight'];
    samehCool = json['sameh_cool'];
    samehExpire = json['sameh_expire'];
    samehCover = json['sameh_cover'];
    samehAdminPriceAfter = json['sameh_admin_price_after'];
    samehNotes = json['sameh_notes'];
    samehCategoryId = json['sameh_category_id'];
    samehSupplierId = json['sameh_supplier_id'];
    samehPartnerId = json['sameh_partner_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['sameh_id'] = this.samehId;
    data['sameh_name'] = this.samehName;
    data['sameh_front_image'] = this.samehFrontImage;
    data['sameh_sku'] = this.samehSku;
    data['sameh_wight'] = this.samehWight;
    data['sameh_cool'] = this.samehCool;
    data['sameh_expire'] = this.samehExpire;
    data['sameh_cover'] = this.samehCover;
    data['sameh_admin_price_after'] = this.samehAdminPriceAfter;
    data['sameh_notes'] = this.samehNotes;
    data['sameh_category_id'] = this.samehCategoryId;
    data['sameh_supplier_id'] = this.samehSupplierId;
    data['sameh_partner_id'] = this.samehPartnerId;
    return data;
  }
}
