import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:system_shop/core/colors/colors.dart';
import 'package:system_shop/core/componant/componant.dart';
import 'package:system_shop/features/login/presentaion/cubit/login_cubit.dart';
import 'package:system_shop/features/login/presentaion/cubit/login_states.dart';
import 'package:system_shop/features/login/presentaion/screens/login_screen/login_screen.dart';
import 'package:system_shop/features/register/presentaion/cubit/register_cubit.dart';
import 'package:system_shop/features/register/presentaion/cubit/register_states.dart';

class RegisterScreen extends StatelessWidget {
  RegisterScreen({super.key});
  String emailError = '';
  String nameError = '';
  String companyError = '';
  String phoneError = '';
  String shopNameError = '';
  String passwordError = '';
  @override
  Widget build(BuildContext context) {
    return BlocProvider<RegisterCubit>(
      create: (context) => RegisterCubit(),
      child: BlocConsumer<RegisterCubit, RegisterStates>(
          listener: (context, state) {},
          builder: (context, state) {
            RegisterCubit cubit = RegisterCubit.get(context);
            return Scaffold(
              body: Padding(
                padding: EdgeInsets.only(top: 60.h, left: 18.w, right: 18.w),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // defaultText(
                      //     txt: 'مشترياتي',
                      //     fontSize: 20,
                      //     color: Color.fromARGB(98, 15, 14, 14),
                      //     fontWeight: FontWeight.bold),
                      SizedBox(
                        height: 20.h,
                      ),
                      defaultText(
                          txt: 'Getting Started',
                          fontSize: 20.sp,
                          color: Color(0xff171717),
                          fontWeight: FontWeight.bold),
                      defaultText(
                          txt: 'Create an account to continue!',
                          fontSize: 11.sp,
                          color: Colors.grey.shade500,
                          fontWeight: FontWeight.bold),

                      SizedBox(
                        height: 30.h,
                      ),
                      defaultText(
                          txt: 'Name',
                          fontSize: 14.sp,
                          // color: Color(0xff8F92A1),
                          fontWeight: FontWeight.normal),
                      SizedBox(
                        height: 5.h,
                      ),
                      Container(
                        height: 45.h,
                        // decoration: BoxDecoration(
                        //   borderRadius: BorderRadius.circular(12),
                        //   border: Border.all(width: .1),
                        // ),
                        child: TextFormField(
                          controller: cubit.nameController,
                          validator: (value) {
                            if (value!.isEmpty) {
                              nameError = 'Name must be not Empty';
                              return nameError;
                            } else {
                              return null;
                            }
                          },
                          decoration: InputDecoration(
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide(
                                      color: AppColors.greyColor, width: 1)),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide(
                                      color: AppColors.mainColor, width: 1)),
                              contentPadding: EdgeInsets.only(top: 30),
                              border: InputBorder.none,
                              // errorText: nameError,
                              hintText: 'Enter your Name',
                              prefixIcon: Icon(CupertinoIcons.person)),
                        ),
                      ),

                      SizedBox(
                        height: 10.h,
                      ),

                      defaultText(
                          txt: 'Email',
                          fontSize: 14.sp,
                          // color: Color(0xff8F92A1),
                          fontWeight: FontWeight.normal),
                      SizedBox(
                        height: 5.h,
                      ),
                      Container(
                        height: 45.h,
                        // decoration: BoxDecoration(
                        //   borderRadius: BorderRadius.circular(12),
                        //   border: Border.all(width: .1),
                        // ),
                        child: TextField(
                          controller: cubit.emailController,
                          // validator: (value) {
                          //   if (value!.isEmpty) {
                          //     emailError = 'Email must be not Empty';
                          //     return emailError;
                          //   } else {
                          //     return null;
                          //   }
                          // },
                          decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(top: 30),
                              border: InputBorder.none,
                              // errorText: emailError,
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide(
                                      color: AppColors.greyColor, width: 1)),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide(
                                      color: AppColors.mainColor, width: 1)),
                              hintText: 'Enter your email',
                              prefixIcon: Icon(Icons.email)),
                        ),
                      ),

                      SizedBox(
                        height: 10.h,
                      ),

                      defaultText(
                          txt: 'phone',
                          fontSize: 14.sp,
                          // color: Color(0xff8F92A1),
                          fontWeight: FontWeight.normal),
                      SizedBox(
                        height: 5.h,
                      ),
                      Container(
                        height: 45.h,
                        // decoration: BoxDecoration(
                        //   borderRadius: BorderRadius.circular(12),
                        //   border: Border.all(width: .1),
                        // ),
                        child: TextFormField(
                          controller: cubit.phoneController,
                          validator: (value) {
                            if (value!.isEmpty) {
                              emailError = 'Phone must be not Empty';
                              return phoneError;
                            } else {
                              return null;
                            }
                          },
                          keyboardType: TextInputType.phone,
                          decoration: InputDecoration(
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide(
                                      color: AppColors.greyColor, width: 1)),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide(
                                      color: AppColors.mainColor, width: 1)),
                              contentPadding: EdgeInsets.only(top: 30),
                              border: InputBorder.none,
                              // errorText: phoneError,
                              hintText: 'Enter your Phone',
                              prefixIcon: Icon(Icons.phone)),
                        ),
                      ),
                      SizedBox(
                        height: 10.h,
                      ),
                      defaultText(
                          txt: 'Shop Name',
                          fontSize: 14.sp,
                          // color: Color(0xff8F92A1),
                          fontWeight: FontWeight.normal),
                      SizedBox(
                        height: 5.h,
                      ),
                      Container(
                        height: 45.h,
                        // decoration: BoxDecoration(
                        //   borderRadius: BorderRadius.circular(12),
                        //   border: Border.all(width: .1),
                        // ),
                        child: TextFormField(
                          controller: cubit.shopNameController,
                          validator: (value) {
                            if (value!.isEmpty) {
                              shopNameError = 'Shop Name must be not Empty';
                              return shopNameError;
                            } else {
                              return null;
                            }
                          },
                          decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(top: 30),
                              // border: InputBorder.none,
                              // errorText: shopNameError,
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide(
                                      color: AppColors.greyColor, width: 1)),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide(
                                      color: AppColors.mainColor, width: 1)),
                              hintText: 'Enter your Shop Name',
                              prefixIcon: Icon(Icons.shop_outlined)),
                        ),
                      ),
                      SizedBox(
                        height: 10.h,
                      ),
                      defaultText(
                          txt: 'Company Name',
                          fontSize: 14.sp,
                          // color: Color(0xff8F92A1),
                          fontWeight: FontWeight.normal),
                      SizedBox(
                        height: 5.h,
                      ),
                      Container(
                        height: 45.h,
                        // decoration: BoxDecoration(
                        //   borderRadius: BorderRadius.circular(12),
                        //   border: Border.all(width: .1),
                        // ),
                        child: TextFormField(
                          controller: cubit.companyController,
                          validator: (value) {
                            if (value!.isEmpty) {
                              companyError = 'Company must be not Empty';
                              return companyError;
                            } else {
                              return null;
                            }
                          },
                          decoration: InputDecoration(
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide(
                                      color: AppColors.greyColor, width: 1)),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide(
                                      color: AppColors.mainColor, width: 1)),
                              contentPadding: EdgeInsets.only(top: 30),
                              // border: InputBorder.none,
                              // errorText: shopNameError,
                              hintText: 'Enter your Company Name',
                              prefixIcon: Icon(CupertinoIcons.home)),
                        ),
                      ),

                      SizedBox(
                        height: 10.h,
                      ),

                      defaultText(
                          txt: 'Password',
                          fontSize: 14.sp,
                          // color: Colors.grey.shade500,
                          fontWeight: FontWeight.normal),
                      SizedBox(
                        height: 5.h,
                      ),

                      Container(
                        height: 45.h,
                        // decoration: BoxDecoration(
                        //   borderRadius: BorderRadius.circular(12),
                        //   border: Border.all(width: .1),
                        // ),
                        child: TextFormField(
                        obscureText: true,
                          controller: cubit.passwordController,
                          validator: (value) {
                            if (value!.isEmpty) {
                              passwordError = 'Password must be not Empty';
                              return passwordError;
                            } else {
                              return null;
                            }
                          },
                          decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(top: 30),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide(
                                      color: AppColors.greyColor, width: 1)),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide(
                                      color: AppColors.mainColor, width: 1)),
                              // border: InputBorder.none,
                              // errorText: passwordError,
                              hintText: 'Enter your Password',
                              prefixIcon: Icon(CupertinoIcons.padlock)),
                        ),
                      ),

                      SizedBox(
                        height: 20.h,
                      ),

                      InkWell(
                        onTap: () {
                          cubit.register();
                        },
                        child: Container(
                          height: 55.h,
                          width: double.infinity,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              color: AppColors.mainColor),
                          child: Center(
                            child: defaultText(
                                txt: 'Register',
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 18.sp),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 20.h,
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          defaultText(
                              txt: 'You have an account? ',
                              fontSize: 11.sp,
                              color: Colors.grey.shade500,
                              fontWeight: FontWeight.bold),
                          InkWell(
                            onTap: () {
                              nextPage(context, LoginScreen());
                            },
                            child: defaultText(
                                txt: 'Sign In',
                                fontSize: 20.sp,
                                color: Color(0xff171717),
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 80.h,
                      ),
                    ],
                  ),
                ),
              ),
            );
          }),
    );
  }
}
