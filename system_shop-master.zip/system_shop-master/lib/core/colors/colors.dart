import 'package:flutter/material.dart';

class AppColors {
  static Color secandColor = Color(0xFFFCEED4);
  static Color buttonGreenColor = Color(0xFF00A86B);
  static Color buttonRedColor = Color(0xFFFD3C4A);
  static Color buttonblueColor = Color(0xFF7F3DFF);
  static Color containerColor = Color.fromARGB(255, 188, 190, 238);
  static Color mainColor = Color(0xFFFF7A00);
  static Color greyColor = Color(0xff8F92A1);
  static Color textColor = Color(0xFF757575);
}
 const customSwatch = MaterialColor(
    0xFFFF5252,
    <int, Color>{
      50: Color(0xFFFFEBEE),
      100: Color(0xFFFFCDD2),
      200: Color(0xFFEF9A9A),
      300: Color(0xFFE57373),
      400: Color(0xFFEF5350),
      500: Color(0xFFFF5252),
      600: Color(0xFFE53935),
      700: Color(0xFFD32F2F),
      800: Color(0xFFC62828),
      900: Color(0xFFB71C1C),
    },
  );
