class FontFamilies{

  static const CAIRO = "Cairo";
  static const JOST_BOld = "Jost Bold";

  static const GE_SS_TWO = "GE SS TWO";
  static const DMSANS = 'DMSans';

}