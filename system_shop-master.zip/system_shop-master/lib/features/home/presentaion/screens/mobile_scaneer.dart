import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:system_shop/core/componant/componant.dart';
import 'package:system_shop/features/home/presentaion/home_cubit/home_cubit.dart';
import 'package:system_shop/features/home/presentaion/home_cubit/home_state.dart';

class QrCodeScannerFront extends StatefulWidget {
  const QrCodeScannerFront({super.key});

  @override
  State<StatefulWidget> createState() => _QrCodeScannerFrontState();
}

class _QrCodeScannerFrontState extends State<QrCodeScannerFront> {
//this variable stored the result of your Qr
  var qrText = '';

//used for flash on
  var flashState = "flashon";
//for  front camera
  var cameraState = "frontCamera";
//controller is used to take the values from Qr and saved it this value
  QRViewController? controller;
  Barcode? result;

  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  void resumeCamera() {
    if (Platform.isAndroid) {
      controller?.pauseCamera();
    }
    controller?.resumeCamera();
  }

  copytext() {
    final qrvalue = ClipboardData(text: qrText);
    Clipboard.setData(qrvalue);
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<HomePageCubit, HomeState>(
        listener: (context, state) {},
        builder: (context, state) {
          var scanArea = (MediaQuery.of(context).size.width < 400 ||
                  MediaQuery.of(context).size.height < 400)
              ? 150.0
              : 300.0;
          return Scaffold(
            appBar: AppBar(
              title: defaultText(
                  txt: "الفحص بكاميرا الموبايل",
                  fontSize: 13,
                  fontWeight: FontWeight.bold),
              actions: [
                IconButton(
                    onPressed: () {
                      if (controller != null) {
                        controller?.toggleFlash();
                        if (_isFlashOn(flashState)) {
                          setState(() {
                            flashState = "flashOff";
                          });
                        } else {
                          setState(() {
                            flashState = "flashOn";
                          });
                        }
                      }
                    },
                    icon: Icon(flashState == "flashOff"
                        ? Icons.flash_off
                        : Icons.flash_on)),
                IconButton(
                    onPressed: () {
                      if (controller != null) {
                        controller!.flipCamera();
                        if (_isBackCamera(cameraState)) {
                          setState(() {
                            cameraState = "frontCamera";
                          });
                        } else {
                          setState(() {
                            cameraState = "backCamera";
                          });
                        }
                      }
                    },
                    icon: Icon(cameraState == "frontCamera"
                        ? Icons.camera_alt_outlined
                        : Icons.camera_alt)),
              ],
            ),
            body: QRView(
              key: qrKey,
              cameraFacing: CameraFacing.front,

              onQRViewCreated: (controller) {
                setState(() {
                  this.controller = controller;
                });
                resumeCamera();
                controller.scannedDataStream.listen((scanData) {
                  setState(() {
                    result = scanData;
                  });
                  print('=========================${result?.code.toString()}');
                  HomePageCubit.get(context).scan(result?.code.toString());
                  // Navigator.pop(context);
                });
              },
              // overlay: QrScannerOverlayShape(
              //   borderColor: Colors.red,
              //   borderRadius: 10,
              //   borderLength: 30,
              //   borderWidth: 10,
              // cutOutSize: scanArea,
              // ),
              onPermissionSet: (ctrl, p) => _onPermissionSet(context, ctrl, p),
            ),
          );
        });
  }

  bool _isFlashOn(String current) {
    return "flashOn" == current;
  }

  bool _isBackCamera(String current) {
    return "backCamera" == current;
  }

  void _onQRViewCreated(QRViewController controller) {
    this.controller = controller;
    controller.scannedDataStream.listen((scanData) {
      setState(() {
        qrText = scanData.code.toString();
      });
      HomePageCubit.get(context).scan(qrText);
    });
  }

  void _onPermissionSet(BuildContext context, QRViewController ctrl, bool p) {
    if (!p) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('no Permission')),
      );
    }
  }
}
