class ApiUrls {
  // static String BASE_URL = 'https://coddaddy.com/company/public/api/v1/';
  static String BASE_URL = 'https://bspc-it.com/kalde/public/api/v1/';
  static String LOGIN_URL = 'auth/shop/login';
  static String REGISTER_URL = 'auth/register';
  static String USER_DATA_URL = 'auth/shop/user-profile';

  // Top Sales
  static String TOP_SALES_URL = 'shop/shop-top-ten';
 
  // RETURN_FUND
  static String GET_RETURN_FUND_URL = 'shop/get-returns';
  static String RETURN_FUND_URL = 'shop/return-fund';


  // Total Sales
  static String TOTAL_SALES_URL = 'shop/shop-total-sell';
 
  // ALL SALES
  static String ALL_SALES_URL = 'shop/shop-sell-history';

  // PENDING CLIENT
  static String PENDING_CLIENT_URL = 'shop/pending-clients';
 
//  GET CREDIT
  static String CREDIT_URL = 'shop/getCredits';
  
  // ACTIVE
  static String ACTIVE_URL = 'shop/active-client';

  // SCAN CLIENT
  static String SCAN_CLIENT_URL = 'shop/scan-client-by-number';
  static String SCAN_URL = 'shop/scan-client';

  // COMPANY
  static String COMPANY_URL = 'shop/companies';

  // ADD_FUND
  static String ADD_FUND_URL = 'shop/add-fund';
  
  // PRODUCT_IMAGE
  static String PRODUCT_IMAGE_URL = 'frontend/product-images';

  // PRODUCT_BY_CATEGORY
  static String PRODUCT_BY_CATEGORY_URL =
      'frontend/products-details-by-category';

  // SERVICES_DETAILS
  static String SERVICES_DETAILS_URL = 'frontend/service-details';

  // STORE_SERVICES
  static String STORE_SERVICES_URL = 'frontend/store-service-contact';
}
