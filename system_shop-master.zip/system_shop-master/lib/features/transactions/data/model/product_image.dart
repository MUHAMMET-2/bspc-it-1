class ProductImagesModel {
  bool? status;
  String? num;
  String? msg;
  List<ProductImageData>? data;

  ProductImagesModel({this.status, this.num, this.msg, this.data});

  ProductImagesModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    num = json['Num'];
    msg = json['msg'];
    if (json['data'] != null) {
      data = <ProductImageData>[];
      json['data'].forEach((v) {
        data!.add(new ProductImageData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['Num'] = this.num;
    data['msg'] = this.msg;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ProductImageData {
  int? samehId;
  int? samehProductId;
  String? samehImage;

  ProductImageData({this.samehId, this.samehProductId, this.samehImage});

  ProductImageData.fromJson(Map<String, dynamic> json) {
    samehId = json['sameh_id'];
    samehProductId = json['sameh_product_id'];
    samehImage = json['sameh_image'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['sameh_id'] = this.samehId;
    data['sameh_product_id'] = this.samehProductId;
    data['sameh_image'] = this.samehImage;
    return data;
  }
}
