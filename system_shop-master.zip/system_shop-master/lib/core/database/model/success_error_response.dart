class SuccessAndErrorResponse{
  
}