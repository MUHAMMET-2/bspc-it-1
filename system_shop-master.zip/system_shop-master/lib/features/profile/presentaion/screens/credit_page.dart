import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:system_shop/core/colors/colors.dart';
import 'package:system_shop/core/componant/componant.dart';
import 'package:system_shop/features/profile/presentaion/profile_cubit/profile_cubit.dart';
import 'package:system_shop/features/profile/presentaion/profile_cubit/profile_state.dart';

class CreditPage extends StatelessWidget {
  const CreditPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ProfileCubit, ProfileState>(
        listener: (context, state) {},
        builder: (context, state) {
          ProfileCubit cubit = ProfileCubit.get(context);
          return Scaffold(
            body: Stack(
              children: [
                Container(
                  height: MediaQuery.of(context).size.height,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          fit: BoxFit.fill,
                          image: AssetImage(
                              'assets/images/Rectangle 225@2x.png'))),
                ),
                cubit.credit == null
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Icon(Icons.wallet_giftcard),
                            SizedBox(
                              height: 10.h,
                            ),
                            defaultText(
                                txt: 'لا يوجد اي رصيد',
                                fontSize: 14.sp,
                                fontWeight: FontWeight.bold)
                          ],
                        ),
                      )
                    : Padding(
                        padding:
                            EdgeInsets.only(top: 80.h, left: 12.w, right: 12.w),
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Icon(Icons.arrow_back),
                                  SizedBox(
                                    width: 15.w,
                                  ),
                                  defaultText(
                                    txt: 'الرصيد',
                                    fontSize: 20.sp,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ],
                              ),
                              Container(
                                height: 550,
                                width: MediaQuery.of(context).size.width,
                                child: ListView.separated(
                                    shrinkWrap: true,
                                    // padding: EdgeInsets.zero,
                                    itemBuilder: (context, index) => Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Container(
                                              height: 80,
                                              width: double.infinity,
                                              padding: EdgeInsets.all(12),
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(16),
                                                  color:
                                                      AppColors.containerColor),
                                            ),
                                            Container(
                                              padding: EdgeInsets.all(10),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                        top: 0.h, left: 15.w),
                                                    child: Row(
                                                      children: [
                                                        Column(
                                                          children: [
                                                            defaultText(
                                                                txt: cubit
                                                                    .credit[
                                                                        index]
                                                                    .date!
                                                                    .toString(),
                                                                color:
                                                                    Colors.red,
                                                                fontSize: 14.sp,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold),
                                                            // defaultText(
                                                            //     txt: cubit
                                                            //         .credit[
                                                            //             index]
                                                            //         .date
                                                            //         .toString(),
                                                            //     fontSize: 12.sp,
                                                            //     fontWeight:
                                                            //         FontWeight
                                                            //             .bold)
                                                          ],
                                                        ),
                                                        SizedBox(
                                                          width: 100.w,
                                                        ),
                                                        Row(
                                                          children: [
                                                            defaultText(
                                                                txt: cubit
                                                                    .credit[
                                                                        index]
                                                                    .credit
                                                                    .toString(),
                                                                fontSize: 16.sp,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold),
                                                            defaultText(
                                                                txt: '  SAR ',
                                                                fontSize: 12.sp,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold)
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 20.w,
                                                  ),
                                                  Stack(
                                                    alignment: Alignment.center,
                                                    children: [
                                                      Container(
                                                        height: 50.h,
                                                        width: 50.w,
                                                        decoration: BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        13),
                                                            color: AppColors
                                                                .secandColor),
                                                      ),
                                                      Image.asset(
                                                          'assets/images/shopping bag.png')
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                    separatorBuilder: (context, index) =>
                                        SizedBox(
                                          height: 12,
                                        ),
                                    itemCount: cubit.credit.length),
                              )
                            ],
                          ),
                        ),
                      )
              ],
            ),
          );
        });
  }
}
