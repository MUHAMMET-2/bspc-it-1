import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:system_shop/core/const/const.dart';
import 'package:system_shop/core/database/api/dio_consumer.dart';
import 'package:system_shop/core/database/api/end_point.dart';
import 'package:system_shop/core/database/cache/cache_helper.dart';
import 'package:system_shop/features/login/data/data_source/remote_data_source.dart';
import 'package:system_shop/features/login/data/models/login_model.dart';
import 'package:system_shop/features/login/presentaion/cubit/login_states.dart';

class LoginCubit extends Cubit<LoginStates> {
  LoginCubit() : super(LoginInstialState());

  static LoginCubit get(context) => BlocProvider.of(context);
  var dioHelper = DioHelper.instance;
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  LoginModel? loginModel;
  Future login() async {
    emit(LoginLoading());
    dioHelper.post(endPoint: ApiUrls.LOGIN_URL, query: {
      "email": emailController.text,
      "password": passwordController.text,
    }).then((value) async {
      loginModel = LoginModel.fromJson(value!.data);
      await CacheHelper.setShared(
          key: AppConst.kLogin, value: loginModel!.accessToken);
      uid = CacheHelper.getShared(key: AppConst.kLogin);
      emit(LoginSuccess());
    }).catchError((er) {
      print(er.toString());
      emit(LoginError());
    });
  }
}
